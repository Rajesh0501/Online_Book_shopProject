package com.book.majorProject.Repository;

import com.book.majorProject.Model.MyOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MyOrderRepo extends JpaRepository<MyOrder,Long> {
}
