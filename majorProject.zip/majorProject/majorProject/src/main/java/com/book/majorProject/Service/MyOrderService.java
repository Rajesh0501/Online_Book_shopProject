package com.book.majorProject.Service;

import com.book.majorProject.Model.MyOrder;
import com.book.majorProject.Repository.MyOrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyOrderService {
    @Autowired
    MyOrderRepo myOrderRepo;
    public void saveOrder(MyOrder myOrder){
        myOrderRepo.save(myOrder);
    }
}
