package com.book.majorProject.Controller;

import com.book.majorProject.DTO.productDTO;
import com.book.majorProject.Model.Category;
import com.book.majorProject.Model.Product;
import com.book.majorProject.Service.ProductService;
import com.book.majorProject.Service.categoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

@Controller
public class AdminController {
    public  String uploadDir ="D:\\majorProject\\majorProject\\src\\main\\resources\\static\\productImages";
    @Autowired
    categoryService categoryService;
    @Autowired
    ProductService productService;

    @GetMapping("/admin")
    public String admin(){
        return "adminHome";
    }
    @GetMapping("/admin/category")
    public String getCat(Model model){
        model.addAttribute("categories", categoryService.getCategory());
        return "categories";
    }
    @GetMapping("/admin/category/add")
    public String getCatAdd(Model model){
        model.addAttribute("category",new Category());
        return "addCategory";
    }
    @PostMapping("/admin/category/add")
    public String postCatAdd(@ModelAttribute("category") Category category){
        categoryService.addCategory(category);
        return "redirect:/admin/category";
    }
    @GetMapping("/admin/category/delete/{id}")
    public String deleteCat(@PathVariable("id") int id){
        categoryService.deleteById(id);
        return "redirect:/admin/category";
    }
    @GetMapping("/admin/category/update/{id}")
    public String updateCat(@PathVariable int id,Model model){
        Optional<Category> category = categoryService.getCategoryById(id);
        if (category.isPresent()){
            model.addAttribute("category",category.get());
            return "addCategory";
        }
        else {
            return "404";
        }

        }


        //product section
        @GetMapping("/admin/products")
    public String getProduct(Model model){
        model.addAttribute("products",productService.getProduct());
        return "products";
        }

    @GetMapping("/admin/products/add")
    public String getProductAdd(Model model){
        model.addAttribute("productDTO",new productDTO());
        model.addAttribute("categories",categoryService.getCategory());
        return "productsAdd";
    }
    @PostMapping("/admin/products/add")
    public String productAddPost(@ModelAttribute("productDTO") productDTO productDTO,
                                 @RequestParam("productImage") MultipartFile file,
                                 @RequestParam("imgName") String imgName) throws IOException {
        Product product = new Product();
        product.setId(productDTO.getId());
        product.setName(productDTO.getName());
        product.setCategory(categoryService.getCategoryById(productDTO.getCategoryId()).get());
        product.setPrice(productDTO.getPrice());
        product.setAuthor(productDTO.getAuthor());
        product.setDescription(productDTO.getDescription());
        String imageUUID;
        if (!file.isEmpty()){
            imageUUID = file.getOriginalFilename();
            Path fileNameAndPath = Paths.get(uploadDir,imageUUID);
            Files.write(fileNameAndPath,file.getBytes());
        }
        else {
            imageUUID = imgName;
        }
        System.out.println(imageUUID+"code will execute");
        product.setImageName(imageUUID);
        productService.addProduct(product);
        return "redirect:/admin/products";
    }



    @GetMapping("/admin/product/delete/{id}")
    public String deleteProduct(@PathVariable Long id){
        productService.removeProductById(id);
        return "redirect:/admin/products";
    }
    @GetMapping("/admin/product/update/{id}")
    public String updateProductGet(@PathVariable long id,Model model){
        Product product = productService.getProductById(id).get();
        productDTO productDTO = new productDTO();
        productDTO.setId(product.getId());
        productDTO.setName((product.getName()));
        productDTO.setCategoryId(product.getCategory().getId());
        productDTO.setPrice(product.getPrice());
        productDTO.setAuthor(product.getAuthor());
        productDTO.setDescription(product.getDescription());
        productDTO.setImageName(product.getImageName());
        model.addAttribute("categories",categoryService.getCategory());
        model.addAttribute("productDTO",productDTO);
        return "productsAdd";
    }



    }


