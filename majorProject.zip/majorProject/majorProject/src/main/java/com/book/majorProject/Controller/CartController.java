package com.book.majorProject.Controller;

import com.book.majorProject.Globle.globalData;
import com.book.majorProject.Model.Product;
import com.book.majorProject.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class CartController {
    @Autowired
    ProductService productService;
    @GetMapping("/addToCart/{id}")
    public String addToCard(@PathVariable long id){
        globalData.cart.add(productService.getProductById(id).get());
        return "redirect:/shop";
    }
    @GetMapping("/cart")
    public String getCart(Model model){
        model.addAttribute("cartCount",globalData.cart.size());
        model.addAttribute("total",globalData.cart.stream().mapToDouble(Product::getPrice).sum());
        model.addAttribute("cart",globalData.cart);
        return "cart";
    }
    @GetMapping("/cart/removeItem/{index}")
    public String removeCartItem(@PathVariable int index){
        globalData.cart.remove(index);
        return "redirect:/cart";
    }
    @GetMapping("/checkout")
    public String checkout(Model model){
        model.addAttribute("total",globalData.cart.stream().mapToDouble(Product::getPrice).sum());
        return "checkout";
    }

}
