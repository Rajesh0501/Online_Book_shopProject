package com.book.majorProject.DTO;

import com.book.majorProject.Model.Category;
import lombok.Data;

import javax.persistence.*;
@Data
public class productDTO {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private int categoryId;
    private double price;
    private String author;
    private String description;
    private String imageName;
}
