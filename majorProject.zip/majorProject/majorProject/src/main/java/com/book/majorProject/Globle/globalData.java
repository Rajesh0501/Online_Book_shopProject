package com.book.majorProject.Globle;

import com.book.majorProject.Model.Product;

import java.util.ArrayList;
import java.util.List;

public class globalData {
    public static List<Product> cart;
    static {
        cart =  new ArrayList<Product>();
    }
}
