package com.book.majorProject.Controller;

import com.book.majorProject.Model.MyOrder;
import com.book.majorProject.Service.MyOrderService;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.security.Principal;
import java.util.Map;
import com.razorpay.*;

@Controller
public class paymentController {
    @Autowired
    MyOrderService myOrderService;
    @Autowired
    UserDetailsService userDetailsService;

    @PostMapping("/user/create_order")
    @ResponseBody
    public String createOrder(@RequestBody Map<String, Object> data, Principal principal)throws RazorpayException,Exception {
        // Your code to process the order data here
        System.out.println(data);
        int amt = Integer.parseInt(data.get("amount").toString());
         RazorpayClient razorpayClient =  new RazorpayClient("rzp_test_80fD4BkhlnaCeE","vCqzaOOkt200EsqgqCdicYCl");
        JSONObject options = new JSONObject();
        options.put("amount", amt*100);
        options.put("currency", "INR");
        options.put("receipt", "txn_123456");

        //creating new order
        Order order = razorpayClient.orders.create(options);
        System.out.println(order);

        //save in the data base;
        MyOrder myOrder = new MyOrder();
         myOrder.setAmount(order.get("amount"));
         myOrder.setOrderId(order.get("order_id"));
         myOrder.setPaymentId(null);
         myOrder.setStatus("created");
         myOrder.setUser(null);
        //user remaining
        myOrder.setReceipt(order.get("receipt"));
        this.myOrderService.saveOrder(myOrder);




        return order.toString();
    }
}

