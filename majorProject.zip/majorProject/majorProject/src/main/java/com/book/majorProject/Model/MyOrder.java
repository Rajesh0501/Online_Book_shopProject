package com.book.majorProject.Model;

import lombok.Data;

import javax.persistence.*;
@Data
@Entity
@Table(name = "orders")
public class MyOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long myOrderID;
    private String orderId;
    private Integer amount;
    private String receipt;
    private String status;
    @ManyToOne
    private User user;
    private String paymentId;
}
